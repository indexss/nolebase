![](assets/Pasted%20image%2020250506181929.webp)
