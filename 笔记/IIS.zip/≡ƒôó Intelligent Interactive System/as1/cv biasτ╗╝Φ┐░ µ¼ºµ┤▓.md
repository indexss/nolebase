https://ar5iv.org/html/2408.11448
