# Week 4 Supervised Learning
太简单了，很快过一遍。只写一些不太确定的内容。
分类器的评判标准：
![](assets/Pasted%20image%2020250211201110.webp)

