---
description: Intro
tags:
  - Sys
  - OS
  - Linux
  - C
---

# Week 0 Intro

### Outline

* 程序员视角的computer architecture
* C编程
  * C程序的结构
  * 指针和内存管理
  * 内存管理的应用
* 多线程编程
* OS话题
  * OS结构
  * 进程管理
  * 内存管理
  * 文件系统
  * IO
  * 内核编程

### 评价细则

80% 期末考试 20% 作业

2次作业不计分，一次记分（记分的那次是基于不计分的第一次作业）
