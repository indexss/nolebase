---
tags:
  - Sys
  - OS
  - Linux
  - C
---
# Week 6 - Consolidation week

